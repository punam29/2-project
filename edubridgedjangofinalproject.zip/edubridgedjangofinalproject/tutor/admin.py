from django.contrib import admin
from .models import TutorFeedback


admin.site.register(TutorFeedback)
