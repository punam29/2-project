# Tuition Management System
A simple web application for tuition management. The project was developed using Django framework as a varsity project.
