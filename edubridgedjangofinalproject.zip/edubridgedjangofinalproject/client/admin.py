from django.contrib import admin
from .models import ClientFeedback


admin.site.register(ClientFeedback)
